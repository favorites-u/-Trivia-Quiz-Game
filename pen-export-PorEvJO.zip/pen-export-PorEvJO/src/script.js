const questionElement = document.getElementById('question');
const answerButtons = document.querySelectorAll('.answer-btn');
const scoreElement = document.getElementById('score');

let score = 0;
let currentQuestionIndex = 0;
let timer;
let timeLeft = 10;

const originalQuestions = [
    { question: "What is 2 + 2?", answers: { A: "3", B: "4", C: "5", D: "6" }, correct: "B" },
    { question: "What is the capital of France?", answers: { A: "Berlin", B: "Madrid", C: "Paris", D: "Rome" }, correct: "C" },
    { question: "What is 10 / 2?", answers: { A: "3", B: "4", C: "5", D: "6" }, correct: "C" },
    { question: "Who wrote 'Romeo and Juliet'?", answers: { A: "Charles Dickens", B: "Jane Austen", C: "William Shakespeare", D: "Mark Twain" }, correct: "C" },
    { question: "Which planet is known as the Red Planet?", answers: { A: "Venus", B: "Mars", C: "Jupiter", D: "Saturn" }, correct: "B" },
    { question: "What is the boiling point of water?", answers: { A: "100°C", B: "0°C", C: "50°C", D: "200°C" }, correct: "A" },
    { question: "Which element has the chemical symbol 'O'?", answers: { A: "Gold", B: "Oxygen", C: "Silver", D: "Iron" }, correct: "B" },
    { question: "What is the capital of Japan?", answers: { A: "Tokyo", B: "Beijing", C: "Seoul", D: "Bangkok" }, correct: "A" },
    { question: "Who painted the Mona Lisa?", answers: { A: "Vincent van Gogh", B: "Leonardo da Vinci", C: "Pablo Picasso", D: "Claude Monet" }, correct: "B" },
    { question: "What is the largest ocean on Earth?", answers: { A: "Atlantic Ocean", B: "Indian Ocean", C: "Arctic Ocean", D: "Pacific Ocean" }, correct: "D" },
];

let questions = [...originalQuestions]; // Clone the original questions

function startQuiz() {
    score = 0;
    currentQuestionIndex = 0;
    shuffleQuestions(); // Shuffle the questions when starting the quiz
    updateScore();
    showQuestion();
}

function shuffleQuestions() {
    // Fisher-Yates (aka Knuth) Shuffle algorithm
    for (let i = questions.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [questions[i], questions[j]] = [questions[j], questions[i]];
    }
}

function showQuestion() {
    resetTimer();
    const question = questions[currentQuestionIndex];
    questionElement.textContent = question.question;
    answerButtons.forEach(button => {
        const answer = button.getAttribute('data-answer');
        button.textContent = question.answers[answer];
    });
    startTimer();
}

function handleAnswer(selectedAnswer) {
    clearInterval(timer); // Stop the timer
    const correctAnswer = questions[currentQuestionIndex].correct;
    
    if (selectedAnswer === correctAnswer) {
        score += 2;
        updateScore();
        nextQuestion();
    } else {
        alert('Wrong answer! The quiz will now restart with new questions.');
        resetQuestionsAndRestart();
    }
}

function nextQuestion() {
    currentQuestionIndex++;
    
    if (currentQuestionIndex < questions.length) {
        showQuestion();
    } else {
        alert('Congratulations! You have completed the quiz.');
        resetQuestionsAndRestart(); // Restart the quiz with shuffled questions
    }
}

function resetQuestionsAndRestart() {
    questions = [...originalQuestions]; // Reset the questions array to the original questions
    startQuiz(); // Restart the quiz
}

function updateScore() {
    scoreElement.textContent = score;
}

function startTimer() {
    timeLeft = 10;
    timer = setInterval(() => {
        timeLeft--;
        updateTimerDisplay();
        if (timeLeft <= 0) {
            clearInterval(timer);
            alert('Time is up! The quiz will now restart with new questions.');
            resetQuestionsAndRestart();
        }
    }, 1000);
}

function resetTimer() {
    clearInterval(timer);
    timeLeft = 10;
    updateTimerDisplay();
}

function updateTimerDisplay() {
    const timerElement = document.getElementById('timer');
    timerElement.textContent = `Time Left: ${timeLeft} seconds`;
}

answerButtons.forEach(button => {
    button.addEventListener('click', (event) => {
        handleAnswer(event.target.getAttribute('data-answer'));
    });
});

// Start the quiz on page load
startQuiz();
